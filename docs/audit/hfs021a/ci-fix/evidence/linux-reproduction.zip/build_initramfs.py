from pathlib import Path
import gzip,stat,tarfile

out=Path(__file__).resolve().parent
entries={}
for filename in ('rootfs.tar.gz','python.apk'):
    with tarfile.open(out/filename,mode='r:gz',ignore_zeros=True) as archive:
        for member in archive:
            name=member.name.removeprefix('./').rstrip('/')
            if not name or name.startswith('.'):
                continue
            if member.isdir():
                mode=stat.S_IFDIR|member.mode; data=b''
            elif member.issym():
                mode=stat.S_IFLNK|member.mode; data=member.linkname.encode()
            elif member.isfile():
                mode=stat.S_IFREG|member.mode; data=archive.extractfile(member).read()
            else:
                continue
            entries[name]=(mode,data)
for name in ('linux-inputs.json','linux_reproduce.py'):
    entries[name]=(stat.S_IFREG|0o644,(out/name).read_bytes())
repo=out.parents[1]
for folder,name in (('scripts','hfs021a_svg_comparison.py'),('tests','test_hfs021a_svg_comparison.py')):
    entries[f'{folder}/{name}']=(stat.S_IFREG|0o644,(repo/folder/name).read_bytes())
site=repo/'.venv/21dev/Lib/site-packages'
entries['usr/lib/python3.12/site-packages/py.py']=(stat.S_IFREG|0o644,(site/'py.py').read_bytes())
for package in ('pytest','_pytest','pluggy','iniconfig','packaging','pygments'):
    for path in (site/package).rglob('*.py'):
        entries['usr/lib/python3.12/site-packages/'+path.relative_to(site).as_posix()]=(stat.S_IFREG|0o644,path.read_bytes())
entries['init']=(stat.S_IFREG|0o755,b'#!/bin/sh\n/bin/mount -t proc proc /proc\n/bin/mount -t sysfs sys /sys\n/bin/mount -t devtmpfs dev /dev\nexport PYTHONHASHSEED=0 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1\n/usr/bin/python3 /linux_reproduce.py\n/usr/bin/python3 -m pytest -q -ra -p no:cacheprovider /tests/test_hfs021a_svg_comparison.py --basetemp=/pytest-tmp\necho LINUX_PYTEST_EXIT=$?\n/bin/busybox poweroff -f\n')
payload=bytearray()
for name in list(entries):
    for parent in Path(name).parents:
        if parent.as_posix() != '.':
            entries.setdefault(parent.as_posix(),(stat.S_IFDIR|0o755,b''))
for ino,(name,(mode,data)) in enumerate(sorted(entries.items(),key=lambda item:(item[0].count('/'),item[0])),1):
    name_bytes=name.encode()+b'\0'
    fields=[ino,mode,0,0,1,0,len(data),0,0,0,0,len(name_bytes),0]
    header=b'070701'+b''.join(f'{n:08x}'.encode() for n in fields)
    payload.extend(header+name_bytes); payload.extend(b'\0'*(-len(payload)%4))
    payload.extend(data); payload.extend(b'\0'*(-len(payload)%4))
name_bytes=b'TRAILER!!!\0'
fields=[0,0,0,0,1,0,0,0,0,0,0,len(name_bytes),0]
payload.extend(b'070701'+b''.join(f'{n:08x}'.encode() for n in fields)+name_bytes)
payload.extend(b'\0'*(-len(payload)%512))
(out/'initramfs.gz').write_bytes(gzip.compress(payload,mtime=0))
print('initramfs:',len(entries),'entries;',len(payload),'uncompressed bytes')
