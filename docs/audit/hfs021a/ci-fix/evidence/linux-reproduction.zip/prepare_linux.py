from pathlib import Path
import ast
import json

root = Path.cwd()
out = root / '.venv/21a-ci-fix'
source = (root / 'src/steel_design/reporting.py').read_text(encoding='utf-8')
tree = ast.parse(source)
names = {'_ordered_pm_points', '_write_i5_interaction_diagram_svg'}
functions = '\n\n'.join(ast.get_source_segment(source, n) for n in tree.body
                        if isinstance(n, ast.FunctionDef) and n.name in names)
capture = json.loads((out / 'ubuntu/cli-examples.json').read_text(encoding='utf-8'))

def find_points(value):
    if isinstance(value, dict):
        if 'interaction_points_by_axis' in value:
            return value['interaction_points_by_axis']
        for item in value.values():
            found = find_points(item)
            if found is not None:
                return found
    if isinstance(value, list):
        for item in value:
            found = find_points(item)
            if found is not None:
                return found
    return None

payload = {}
for label, record in capture.items():
    if record['execution']['returncode']:
        continue
    result = json.loads(record['execution']['stdout'])
    if result.get('artifacts', {}).get('interaction_diagram_i5_method2_image') is None:
        continue
    name = label.split('/')[0]
    detail = capture[name + '/detailed']['normalized_details']
    points = find_points(detail)
    assert points is not None, label
    case = json.loads((root / 'examples' / name).read_text(encoding='utf-8'))
    payload['after/' + label + '/case-0.svg'] = {'points': points, 'loads': case['loads']}
assert len(payload) == 6
(out / 'linux-inputs.json').write_text(json.dumps(payload), encoding='utf-8')
program = '''from __future__ import annotations
from pathlib import Path
from types import SimpleNamespace
import base64,json,sys,platform
'''+functions+'''
print('LINUX_ENV='+json.dumps({'platform':sys.platform,'python':sys.version,'uname':list(platform.uname())}),flush=True)
inputs=json.loads(Path('/linux-inputs.json').read_text())
for name, data in inputs.items():
    path=Path('/case.svg')
    case=SimpleNamespace(loads=SimpleNamespace(**data['loads']))
    _write_i5_interaction_diagram_svg(points_by_axis=data['points'],case=case,output_path=path)
    print('SVG_BYTES='+json.dumps({'name':name,'base64':base64.b64encode(path.read_bytes()).decode()}),flush=True)
print('LINUX_REPRODUCTION_SUCCESS',flush=True)
'''
(out / 'linux_reproduce.py').write_text(program, encoding='utf-8')
print('Prepared', len(payload), 'Linux SVG cases from remote memory; functions extracted without edits')
