# Linux rendering reproduction (audit only)

The original GitHub run did not preserve SVG files. These are NEW Linux
reproductions from its recorded numeric points, not recovered remote SVGs.
No full engine suite is run in this minimal Alpine guest.

1. Start at repository root, HEAD ae5f54b plus the SVG comparator correction.
   Extract this ZIP into `.venv/21a-ci-fix` (a new directory when reproducing).
   Extract `remote-ubuntu.zip` from the report's evidence into
   `.venv/21a-ci-fix/ubuntu`.
2. Provide the documented dev environment at `.venv/21dev` using the existing
   project dev constraints. `build_initramfs.py` copies only the installed pure
   Python pytest dependencies into the guest; it does not copy Windows binaries.
3. Download the four files named in `toolchain.json` into `.venv/21a-ci-fix`.
   Verify their SHA-256. Mutable Alpine URLs can later change; a hash mismatch
   requires recording a NEW toolchain, not claiming this capture was reproduced.
   Extract QEMU with installed 7-Zip (do not run its system installer):

```powershell
& 'C:\Program Files\7-Zip\7z.exe' x .venv/21a-ci-fix/qemu-setup.exe '-o.venv/21a-ci-fix/qemu' -y
.venv/21dev/Scripts/python.exe -X utf8 .venv/21a-ci-fix/prepare_linux.py
.venv/21dev/Scripts/python.exe -X utf8 .venv/21a-ci-fix/build_initramfs.py
& .venv/21a-ci-fix/qemu/qemu-system-x86_64.exe -machine accel=tcg -m 256 -nodefaults -no-reboot -display none -serial stdio -kernel .venv/21a-ci-fix/vmlinuz -initrd .venv/21a-ci-fix/initramfs.gz -append 'console=ttyS0 rdinit=/init quiet' *> .venv/21a-ci-fix/linux-console.log
.venv/21dev/Scripts/python.exe -X utf8 .venv/21a-ci-fix/diagnose.py
```

Commands shown use Windows PowerShell 5.1; its redirected console file is UTF-16.
The SVG payload is base64, so the host's console encoding/newlines cannot change
the recovered SVG bytes. `diagnose.py` writes them unchanged and checks CRLF->LF
equality against the historical HFS-021 ZIP. To reproduce its additional Windows
renderer check, use the same two extracted functions, same `linux-inputs.json`,
and a SimpleNamespace with those loads, writing to `windows-svg/<member>`.
Those six Windows outputs are included in this archive. Never overwrite a
previous capture; choose new output paths and adapt these audit-only commands.

Guest success markers: `LINUX_REPRODUCTION_SUCCESS`, `29 passed`,
`LINUX_PYTEST_EXIT=0`. Poweroff exits QEMU. The test module/helper copied into
the guest are the actual repository files. Network devices are absent.

`linux-console.log` is the initial successful renderer-only boot; the three
`linux-tests-console*.log` files record two dependency-assembly failures and
the final 29-pass guest. Incidents explicitly identify the first failed boot
whose full log was overwritten. No failed run is counted as a passing suite.
