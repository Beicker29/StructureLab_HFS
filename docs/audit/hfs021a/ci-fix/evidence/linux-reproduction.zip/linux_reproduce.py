from __future__ import annotations
from pathlib import Path
from types import SimpleNamespace
import base64,json,sys,platform
def _ordered_pm_points(point_payload: dict) -> list[dict]:
    if not isinstance(point_payload, dict):
        return []
    points = point_payload.get("points", point_payload)
    if not isinstance(points, dict):
        return []
    order = ["A", "E", "C", "D", "B"]
    return [points[key] for key in order if key in points and isinstance(points[key], dict)]

def _write_i5_interaction_diagram_svg(
    *,
    points_by_axis: dict,
    case: SteelCase,
    output_path: Path,
) -> str:
    width = 900
    height = 620
    pad_left = 90
    pad_right = 30
    pad_top = 50
    pad_bottom = 70
    plot_w = width - pad_left - pad_right
    plot_h = height - pad_top - pad_bottom

    all_m = [abs(float(case.loads.Mux)), abs(float(case.loads.Muy))]
    all_p = [max(0.0, float(case.loads.Pu))]
    for axis_key in ("x", "y"):
        axis_payload = points_by_axis.get(axis_key)
        for point in _ordered_pm_points(axis_payload) if isinstance(axis_payload, dict) else []:
            all_m.append(max(0.0, float(point.get("M_kN_m", 0.0))))
            all_p.append(max(0.0, float(point.get("P_kN", 0.0))))

    max_m = max(all_m) if any(value > 0.0 for value in all_m) else 1.0
    max_p = max(all_p) if any(value > 0.0 for value in all_p) else 1.0

    def _x(m_kN_m: float) -> float:
        return pad_left + (max(0.0, m_kN_m) / max_m) * plot_w

    def _y(p_kN: float) -> float:
        return pad_top + (1.0 - (max(0.0, p_kN) / max_p)) * plot_h

    axis_styles = {
        "x": {"label": "x-axis", "color": "#1f77b4", "demand_m": abs(float(case.loads.Mux))},
        "y": {"label": "y-axis", "color": "#d62728", "demand_m": abs(float(case.loads.Muy))},
    }
    demand_p = max(float(case.loads.Pu), 0.0)
    svg_parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect x="0" y="0" width="100%" height="100%" fill="#ffffff"/>',
        f'<line x1="{pad_left}" y1="{pad_top}" x2="{pad_left}" y2="{height - pad_bottom}" stroke="#222" stroke-width="1.5"/>',
        f'<line x1="{pad_left}" y1="{height - pad_bottom}" x2="{width - pad_right}" y2="{height - pad_bottom}" stroke="#222" stroke-width="1.5"/>',
        f'<text x="{width/2:.1f}" y="24" text-anchor="middle" font-family="Arial" font-size="18">I5 Method 2 Interaction Diagram</text>',
        f'<text x="{width/2:.1f}" y="{height-20}" text-anchor="middle" font-family="Arial" font-size="14">Moment M (kN-m)</text>',
        f'<text x="24" y="{height/2:.1f}" text-anchor="middle" font-family="Arial" font-size="14" transform="rotate(-90 24 {height/2:.1f})">Axial Compression P (kN)</text>',
    ]

    for idx in range(6):
        frac = idx / 5.0
        gx = pad_left + frac * plot_w
        gy = pad_top + frac * plot_h
        m_tick = frac * max_m
        p_tick = (1.0 - frac) * max_p
        svg_parts.append(f'<line x1="{gx:.1f}" y1="{pad_top}" x2="{gx:.1f}" y2="{height-pad_bottom}" stroke="#e5e5e5" stroke-width="1"/>')
        svg_parts.append(f'<line x1="{pad_left}" y1="{gy:.1f}" x2="{width-pad_right}" y2="{gy:.1f}" stroke="#e5e5e5" stroke-width="1"/>')
        svg_parts.append(f'<text x="{gx:.1f}" y="{height-pad_bottom+18}" text-anchor="middle" font-family="Arial" font-size="11">{m_tick:.1f}</text>')
        svg_parts.append(f'<text x="{pad_left-10}" y="{gy+4:.1f}" text-anchor="end" font-family="Arial" font-size="11">{p_tick:.1f}</text>')

    legend_y = pad_top + 12
    for axis_key, style in axis_styles.items():
        axis_payload = points_by_axis.get(axis_key)
        if not isinstance(axis_payload, dict):
            continue
        ordered = _ordered_pm_points(axis_payload)
        if not ordered:
            continue
        coords = " ".join(f"{_x(float(point.get('M_kN_m', 0.0))):.2f},{_y(float(point.get('P_kN', 0.0))):.2f}" for point in ordered)
        svg_parts.append(
            f'<polyline fill="none" stroke="{style["color"]}" stroke-width="2" points="{coords}"/>'
        )
        for point in ordered:
            px = _x(float(point.get("M_kN_m", 0.0)))
            py = _y(float(point.get("P_kN", 0.0)))
            svg_parts.append(f'<circle cx="{px:.2f}" cy="{py:.2f}" r="3.5" fill="{style["color"]}"/>')

        dx = _x(style["demand_m"])
        dy = _y(demand_p)
        svg_parts.append(f'<line x1="{dx-5:.2f}" y1="{dy-5:.2f}" x2="{dx+5:.2f}" y2="{dy+5:.2f}" stroke="{style["color"]}" stroke-width="2"/>')
        svg_parts.append(f'<line x1="{dx-5:.2f}" y1="{dy+5:.2f}" x2="{dx+5:.2f}" y2="{dy-5:.2f}" stroke="{style["color"]}" stroke-width="2"/>')

        svg_parts.append(f'<line x1="{width-220}" y1="{legend_y}" x2="{width-190}" y2="{legend_y}" stroke="{style["color"]}" stroke-width="2"/>')
        svg_parts.append(f'<text x="{width-185}" y="{legend_y+4}" font-family="Arial" font-size="11">Interaction {style["label"]}</text>')
        legend_y += 20
        svg_parts.append(f'<line x1="{width-220}" y1="{legend_y-4}" x2="{width-210}" y2="{legend_y+6}" stroke="{style["color"]}" stroke-width="2"/>')
        svg_parts.append(f'<line x1="{width-220}" y1="{legend_y+6}" x2="{width-210}" y2="{legend_y-4}" stroke="{style["color"]}" stroke-width="2"/>')
        svg_parts.append(f'<text x="{width-185}" y="{legend_y+4}" font-family="Arial" font-size="11">Demand {style["label"]}</text>')
        legend_y += 22

    svg_parts.append("</svg>")
    output_path.write_text("\n".join(svg_parts), encoding="utf-8")
    return str(output_path)
print('LINUX_ENV='+json.dumps({'platform':sys.platform,'python':sys.version,'uname':list(platform.uname())}),flush=True)
inputs=json.loads(Path('/linux-inputs.json').read_text())
for name, data in inputs.items():
    path=Path('/case.svg')
    case=SimpleNamespace(loads=SimpleNamespace(**data['loads']))
    _write_i5_interaction_diagram_svg(points_by_axis=data['points'],case=case,output_path=path)
    print('SVG_BYTES='+json.dumps({'name':name,'base64':base64.b64encode(path.read_bytes()).decode()}),flush=True)
print('LINUX_REPRODUCTION_SUCCESS',flush=True)
