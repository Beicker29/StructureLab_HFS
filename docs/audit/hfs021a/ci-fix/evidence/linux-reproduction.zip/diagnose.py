from pathlib import Path
from zipfile import ZipFile
import base64,hashlib,json

out=Path(__file__).resolve().parent
lines=(out/'linux-console.log').read_text(encoding='utf-16').splitlines()
assert 'LINUX_REPRODUCTION_SUCCESS' in lines
environment=json.loads(next(s.removeprefix('LINUX_ENV=') for s in lines if s.startswith('LINUX_ENV=')))
assert environment['platform']=='linux'
records={}
def stats(data):
    data.decode('utf-8',errors='strict')
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'encoding':'valid UTF-8; ASCII subset; no BOM' if data.isascii() else 'valid UTF-8',
            'crlf':data.count(b'\r\n'),'bare_lf':data.count(b'\n')-data.count(b'\r\n'),
            'bare_cr':data.count(b'\r')-data.count(b'\r\n')}
with ZipFile('docs/audit/hfs021/evidence/diagrams.zip') as reference:
    for line in lines:
        if not line.startswith('SVG_BYTES='):
            continue
        item=json.loads(line.removeprefix('SVG_BYTES=')); name=item['name']
        linux=base64.b64decode(item['base64']); windows=reference.read(name)
        path=out/'linux-svg'/name; path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(linux)
        assert (out/'windows-svg'/name).read_bytes()==windows
        a=linux.replace(b'\r\n',b'\n');b=windows.replace(b'\r\n',b'\n')
        assert a==b,name
        records[name]={'linux_reproduction':stats(linux),'windows_historical_reference':stats(windows),
                      'raw_equal':linux==windows,'crlf_to_lf_only_equal':True,
                      'normalized_sha256':hashlib.sha256(a).hexdigest(),
                      'first_raw_difference_positions_zero_based':[i for i,(x,y) in enumerate(zip(linux,windows)) if x!=y][:12],
                      'any_other_content_difference':False}
assert len(records)==6
result={'remote_svg_bytes_available':False,'remote_artifacts_svg_members':[],
        'linux_reproduction_environment':environment,'renderer_scope':'Two exact source functions extracted without edits; case loads from versioned examples, interaction points from Ubuntu remote detailed memory; not a full Linux engine run',
        'diagrams':records}
(out/'diagnosis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for name,r in records.items():print(name,r['linux_reproduction']['bytes'],r['windows_historical_reference']['bytes'],r['linux_reproduction']['bare_lf'],'line breaks; other changes:',r['any_other_content_difference'])
