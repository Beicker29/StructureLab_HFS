"""StructureLab HFS domain package."""
