"""Read-only tracked-source inventory for HFS-021B; absence is not proof of death."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path.cwd()
GIT = r'D:\Users\byomayusa\AppData\Local\GitHubDesktop\app-3.6.7\resources\app\git\cmd\git.exe'
OUT = ROOT / '.venv/21b-work'
OUT.mkdir(exist_ok=True)
names = subprocess.check_output([GIT, 'ls-files'], text=True).splitlines()
run_source = (ROOT / 'src/steel_design/run.py').read_text(encoding='utf-8')
run_tree = ast.parse(run_source)
report_aliases = [a.asname or a.name for n in run_tree.body if isinstance(n, ast.ImportFrom)
                  and n.module == 'reporting' for a in n.names if a.name.startswith('_')]
symbols = sorted(set(report_aliases + ['_build_case_section', '_run_single_case',
    '_extract_output_options', '_merge_case_payload', '_build_custom_section',
    'extract_output_options', 'merge_case_payload', 'OutputOptions', 'build_custom_section',
    'run_with_context', 'execute_case', 'validate_bundle_shape']))
result = {'base': subprocess.check_output([GIT, 'rev-parse', 'HEAD'], text=True).strip(),
          'scope': 'Tracked Python, Markdown and package/workflow configuration; historical audit documents classified separately. No inference about inaccessible/unversioned/external consumers.',
          'symbols': {s: [] for s in symbols}, 'dynamic_references': [], 'read_errors': [], 'files': {}}
for name in names:
    path = ROOT / name
    if path.suffix not in ('.py', '.md', '.toml', '.ini', '.yml', '.yaml'):
        continue
    try:
        raw = path.read_bytes(); source = raw.decode('utf-8-sig')
    except (OSError, UnicodeError) as exc:
        result['read_errors'].append({'file': name, 'type': type(exc).__name__, 'message': str(exc)})
        continue
    historical = name.startswith('docs/audit/')
    result['files'][name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'historical': historical}
    for number, line in enumerate(source.splitlines(), 1):
        for symbol in symbols:
            if re.search(r'(?<!\w)' + re.escape(symbol) + r'(?!\w)', line):
                result['symbols'][symbol].append({'file': name, 'line': number, 'text': line.strip(), 'historical': historical})
    if path.suffix == '.py' and not historical:
        try:
            tree = ast.parse(source)
        except SyntaxError as exc:
            result['read_errors'].append({'file': name, 'type': 'SyntaxError', 'message': str(exc)})
            continue
        for node in ast.walk(tree):
            dynamic = isinstance(node, ast.Call) and (
                isinstance(node.func, ast.Name) and node.func.id in ('getattr', 'setattr', 'hasattr', 'globals', 'vars', 'eval', 'exec', '__import__')
                or isinstance(node.func, ast.Attribute) and node.func.attr in ('import_module', 'setattr', 'patch', 'setitem', 'getmembers'))
            wildcard = isinstance(node, ast.ImportFrom) and any(a.name == '*' for a in node.names)
            if dynamic or wildcard:
                result['dynamic_references'].append({'file': name, 'line': node.lineno,
                    'code': ast.get_source_segment(source, node), 'kind': 'wildcard_import' if wildcard else 'dynamic_access'})
(OUT / 'consumer-scan.json').write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
print('Read', len(result['files']), 'tracked text files;', len(result['dynamic_references']), 'dynamic candidates;', len(result['read_errors']), 'read/parse errors')
for symbol in symbols:
    live = [r for r in result['symbols'][symbol] if not r['historical']]
    print(symbol, sorted({r['file'] for r in live}))
