"""Archive new HFS-021B captures without rewriting historical evidence."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,shutil,subprocess

ROOT=Path.cwd();WORK=ROOT/'.venv/21b-work';OUT=ROOT/'docs/audit/hfs021b/evidence'
GIT=r'D:\Users\byomayusa\AppData\Local\GitHubDesktop\app-3.6.7\resources\app\git\cmd\git.exe'
BASE='35dd7b8e09f05b8ac77af1ba0b7b735d59456b6a'
OUT.mkdir(parents=True,exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def command(args):
    p=subprocess.run(args,cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    return {'command':args,'cwd':str(ROOT),'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}

summaries={}
for phase,folder in [('before','.venv/21b-before'),('after','.venv/21b-after2')]:
    directory=ROOT/folder;verification=json.loads((directory/'verification.json').read_text())
    assert verification['accepted']
    suites={}
    for name,records in verification['suites'].items():
        item={key:sum(int(r[key]) for r in records) for key in ('tests','failures','errors','skipped')}
        item['subtests']=12 if name=='original' else 0
        item['passed_methods']=item['tests']-item['subtests']
        assert all(item[k]==0 for k in ('failures','errors','skipped'))
        suites[name]=item
    assert sum(x['passed_methods'] for x in suites.values())==1819
    assert len(suites)==15
    summaries[phase]={'passed_methods':1819,'passed_subtests':12,'failed':0,'errors':0,'skipped':0,'xfail':0,'xpass':0,
                      'suites':suites,'environment':json.loads((directory/'environment.json').read_text()),
                      'engine_examples':12,'cli_memory_scenarios':24,'svg_diagrams':6,'verification_accepted':True,
                      'editable_api_additional_passed':28}
    manifest=json.loads((directory/'SHA256SUMS.json').read_text())
    assert all(sha((directory/n).read_bytes())==digest for n,digest in manifest.items())
    with ZipFile(OUT/f'{phase}.zip','w',ZIP_DEFLATED) as z:
        for p in sorted(directory.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(directory).as_posix())
failed=ROOT/'.venv/21b-after'
assert json.loads((failed/'ruff.json').read_text())['returncode']==1
with ZipFile(OUT/'failed-import-attempt.zip','w',ZIP_DEFLATED) as z:
    for p in sorted(failed.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(failed).as_posix())
for name in ('consumer-scan.json','scope-verification.json','namespace-comparison.json',
             'namespace-before-command.json','namespace-after-command.json','results-comparison.json','head-transition.json'):
    shutil.copyfile(WORK/name,OUT/name)
with ZipFile(OUT/'audit-tools.zip','w',ZIP_DEFLATED) as z:
    for name in ('inventory_consumers.py','probe_namespace.py','verify_cleanup.py','preserve_evidence.py'):
        z.write(WORK/name,name)
write(OUT/'validation.json',{'base':BASE,'current_version':'0.2.0','captures':summaries,
    'new_tests_added':0,'previous_tests_changed':0,'new_dependencies':0,
    'failed_attempt':{'directory':'.venv/21b-after','exit':1,'stage':'ruff','reason':'Two direct renamed compatibility imports flagged F401; corrected using a private canonical module reference. No lint suppressions or test changes.'},
    'results':'Exact before/after under existing policies; same-platform SVG bytes also identical',
    'hfs021a_ci_closed':40736064324,
    'hfs021b_ci_observation':json.loads((OUT/'hfs021b-ci-observation.json').read_text()),
    'final_evidence_not_published_by_agent':True})
status=command([GIT,'status','--short','--untracked-files=all'])
diff=command([GIT,'diff','--check']);assert diff['returncode']==0
changed=subprocess.check_output([GIT,'diff','--name-only',BASE],text=True).splitlines()
assert set(changed)=={'AGENTS.md','docs/ROADMAP.md','docs/architecture/dry-inventory.md','src/steel_design/run.py',
    'docs/audit/hfs021b/report.md','docs/audit/hfs021b/cleanup-inventory.md','docs/audit/hfs021b/evidence/hfs021a-closure-ci.json'}
paths=list(changed)
paths += [p.relative_to(ROOT).as_posix() for p in OUT.iterdir() if p.name not in ('file-inventory.json','SHA256SUMS.json')]
paths += ['docs/audit/hfs021b/evidence/file-inventory.json','docs/audit/hfs021b/evidence/SHA256SUMS.json']
paths=sorted(set(paths))
inventory={'base':BASE,'changed_tracked_since_base':changed,'all_deliverable_paths':paths,'git_status':status,'git_diff_check':diff,
           'files':{},'archives':{},'pending':['Independent review of HFS-021B','User commit/push; no automatic publication','Future explicit compatibility decision for deferred facades'],
           'historical_evidence_unchanged':True,'self_and_checksum_hashes_excluded_to_avoid_cycles':True}
for name in paths:
    p=ROOT/name
    if p.name in ('file-inventory.json','SHA256SUMS.json'):continue
    inventory['files'][name]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
    if p.suffix=='.zip':
        with ZipFile(p) as z:
            inventory['archives'][name]={n:{'bytes':len(z.read(n)),'sha256':sha(z.read(n))} for n in z.namelist()}
write(OUT/'file-inventory.json',inventory)
write(OUT/'SHA256SUMS.json',{p.name:sha(p.read_bytes()) for p in sorted(OUT.iterdir()) if p.name!='SHA256SUMS.json'})
print('HFS-021B evidence preserved:',len(paths),'deliverable files;',len(summaries['after']['suites']),'suites; 1819 +12 before/after')
