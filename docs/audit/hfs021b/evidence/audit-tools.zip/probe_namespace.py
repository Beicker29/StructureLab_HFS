"""Snapshot installed module bindings and committed facade identity, no source injection."""
import inspect
import json
from steel_design import run, engine, execution, reporting
from steel_design.sections.geometry import build_custom_section

aliases = ['_sanitize_filename', '_build_global_summary', '_build_chapter_admissibility',
           '_build_compact_admissibility', '_extract_shared_context', '_infer_check_units',
           '_extract_capacity_from_memory', '_build_dcr_trace', '_extract_i5_method2_points',
           '_ordered_pm_points', '_write_i5_interaction_diagram_svg',
           '_write_i5_interaction_diagram_png', '_write_detailed_results_file',
           '_build_execution_results_dir']
assert all(getattr(run, name) is getattr(reporting, name) for name in aliases)
assert run._extract_output_options is execution.extract_output_options
assert run._merge_case_payload is execution.merge_case_payload
assert run.OutputOptions is execution.OutputOptions
assert engine._build_custom_section is build_custom_section

def describe(value):
    if inspect.ismodule(value):
        return {'kind': 'module', 'name': value.__name__}
    result = {'kind': type(value).__name__, 'owner': getattr(value, '__module__', None),
              'qualname': getattr(value, '__qualname__', None)}
    if callable(value):
        result['signature'] = str(inspect.signature(value))
    return result

print(json.dumps({'origin': run.__file__, 'run_bindings': {
    name: describe(value) for name, value in vars(run).items() if not name.startswith('__')},
    'reporting_facades_identity': aliases, 'execution_facades_identity': True,
    'engine_geometry_identity': True,
    'public_engine_methods': {name: describe(getattr(engine.SteelDesignEngine, name))
                              for name in ('run', 'run_with_context')}}, indent=2))
