"""Reproducible HFS-021B scope/installed namespace/results proof; no engine edits."""
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

ROOT = Path.cwd()
BASE = '35dd7b8e09f05b8ac77af1ba0b7b735d59456b6a'
EXPECTED_HEAD = '3f9669b36a883463aa4b4893a0b4716420b50b0c'
GIT = r'D:\Users\byomayusa\AppData\Local\GitHubDesktop\app-3.6.7\resources\app\git\cmd\git.exe'
OUT = ROOT / '.venv/21b-work'

def run(command, cwd=ROOT):
    env = os.environ.copy()
    env.pop('PYTHONPATH', None)
    env.pop('PYTHONHOME', None)
    env.update(PYTHONUTF8='1', PYTHONNOUSERSITE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
    result = subprocess.run(list(map(str, command)), cwd=cwd, env=env, capture_output=True, text=True, encoding='utf-8')
    record = {'command': list(map(str, command)), 'cwd': str(cwd), 'returncode': result.returncode,
              'stdout': result.stdout, 'stderr': result.stderr}
    assert result.returncode == 0, record
    return record

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

def digest(data):
    return hashlib.sha256(data).hexdigest()

head=run([GIT,'rev-parse','HEAD']); branch=run([GIT,'branch','--show-current'])
assert head['stdout'].strip()==EXPECTED_HEAD and branch['stdout'].strip()=='main'
ancestry=run([GIT,'merge-base','--is-ancestor',BASE,EXPECTED_HEAD])
transition=run([GIT,'show','--format=fuller','--stat',EXPECTED_HEAD])
write('head-transition.json',{'starting_base':BASE,'externally_created_commit':EXPECTED_HEAD,
    'agent_created_commit_or_push':False,'ancestry':ancestry,'commit':transition,
    'initial_scope_guard_exit':1,'reason':'HEAD changed while audit was running; guard stopped before comparison. Reviewed seven changed files, all within task scope; original base and source checks preserved.'})
original=run([GIT,'show',BASE+':src/steel_design/run.py'])['stdout']
actual=(ROOT/'src/steel_design/run.py').read_text(encoding='utf-8')
expected=ast.parse(original)
names={'extract_output_options':'_extract_output_options','merge_case_payload':'_merge_case_payload'}
for node in expected.body:
    if isinstance(node,ast.ImportFrom) and node.module=='execution':
        node.names=[alias for alias in node.names if alias.name not in names]
    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
        for canonical,facade in names.items():
            if node.targets[0].id==facade:
                assert isinstance(node.value,ast.Name) and node.value.id==canonical
                node.value=ast.Attribute(value=ast.Name(id='_execution',ctx=ast.Load()),attr=canonical,ctx=ast.Load())
index=next(i for i,n in enumerate(expected.body) if isinstance(n,ast.ImportFrom) and n.module=='models')
expected.body.insert(index,ast.parse('from . import execution as _execution').body[0])
assert ast.dump(expected,include_attributes=False)==ast.dump(ast.parse(actual),include_attributes=False)
def function_sources(source):
    return {n.name:ast.get_source_segment(source,n) for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
assert function_sources(original)==function_sources(actual)

protected=run([GIT,'diff','--exit-code',BASE,'--','src/steel_design',':(exclude)src/steel_design/run.py',
    'tests','scripts','examples','data','docs/audit/hfs020','docs/audit/hfs021','docs/audit/hfs021a',
    'docs/contracts','docs/adr','docs/normative','pyproject.toml','MANIFEST.in','requirements.txt','requirements','.github'])
scope={'base':BASE,'head':head,'branch':branch,'protected_diff':protected,
       'run_full_AST_matches_only_allowed_import_and_binding_change':True,
       'run_all_function_bodies_signatures_annotations_unchanged':True,
       'run_original_source_sha256_LF':digest(original.encode()),'run_current_source_sha256_LF':digest(actual.encode()),
       'removed_bindings':['run.extract_output_options','run.merge_case_payload'],
       'added_private_module_reference':'run._execution',
       'version_preserved':'0.2.0'}
namespaces={};captures={}
for phase,directory in (('before','.venv/21b-before'),('after','.venv/21b-after2')):
    capture=ROOT/directory
    verification=json.loads((capture/'verification.json').read_text())
    assert verification['accepted']
    captures[phase]=verification
    work=Path(verification['external_work'])
    executable=work/'wheel/Scripts/python.exe'
    record=run([executable,'-I','-B',OUT/'probe_namespace.py'],work/'empty')
    write(f'namespace-{phase}-command.json',record)
    namespaces[phase]=json.loads(record['stdout'])
before=namespaces['before']['run_bindings'];after=namespaces['after']['run_bindings']
assert set(before)-set(after)==set(names)
assert set(after)-set(before)=={'_execution'}
assert all(before[name]==after[name] for name in set(before)&set(after))
assert namespaces['before']['public_engine_methods']==namespaces['after']['public_engine_methods']
write('namespace-comparison.json',{'before':namespaces['before'],'after':namespaces['after'],
    'removed':sorted(set(before)-set(after)),'added':sorted(set(after)-set(before)),
    'all_retained_binding_owners_signatures_equal':True})

wb,=(ROOT/'.venv/21b-before/dist').glob('*.whl');wa,=(ROOT/'.venv/21b-after2/dist').glob('*.whl')
runtime={}
with ZipFile(wb) as b,ZipFile(wa) as a:
    for path in sorted((ROOT/'src/steel_design').rglob('*.py')):
        name=path.relative_to(ROOT/'src').as_posix()
        prior,current=b.read(name),a.read(name)
        assert path.read_bytes()==current,name
        if name!='steel_design/run.py':assert prior==current,name
        runtime[name]={'before':digest(prior),'after':digest(current),'identical_bytes':prior==current}
assert len(runtime)==44 and sum(not r['identical_bytes'] for r in runtime.values())==1
scope['runtime_wheels_and_checkout']=runtime
scope['git_diff_check']=run([GIT,'diff','--check'])
scope['staged']=run([GIT,'diff','--cached','--name-only'])
assert not scope['staged']['stdout'].strip()
write('scope-verification.json',scope)

sys.path.insert(0,str(ROOT/'scripts'))
from compare_hfs021 import compare_results
comparison=compare_results(ROOT/'.venv/21b-before',ROOT/'.venv/21b-after2')
write('results-comparison.json',comparison)
print('HFS-021B: 43 runtime files byte-identical; run functions identical; namespace delta exactly two retired bindings plus private module reference; 12/24/6 exact results')
